const reccordService = require("../services/recordService");

const getRecordForWorkout = (req, res) => {
  try {
    const record = reccordService.getRecordForWorkout();
    res.send({ status: "OK", record });
  } catch (error) {
    res
      .status(error?.status || 500)
      .send({ status: "FAILED", data: { error: error?.message || error } });
  }
};
  module.exports = {
    getRecordForWorkout,
  };