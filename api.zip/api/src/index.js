const express = require("express");
const bodyParser = require("body-parser");
const v1WorkoutRouter = require("./v1/routes/workoutRoutes");//se llama el archivo en routes para los parametros
const { swaggerDocs: V1SwaggerDocs } = require("./v1/swagger");
const apicache = require("apicache");//cache

const app = express();
const PORT = process.env.PORT || 3000;/**se declara la variable y numero de puerto */
const cache = apicache.middleware; //[cache]

app.use(bodyParser.json());
app.use("/api/v1/workouts", v1WorkoutRouter);
app.use(cache("2 minutes")); //[En caso de usar cache]

app.listen(PORT, () => {
  console.log(`API corriendo en el puerto ${PORT}`);
  V1SwaggerDocs(app, PORT);
});
